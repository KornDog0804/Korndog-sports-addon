# KornDog Sports — Stremio Addon

## What's in here
- `netlify/functions/` — the live addon (manifest, catalog, stream) that Netlify actually runs
- `lib/pluto.js` — Pluto TV source module (sports/combat/wrestling/motorsports filter)
- `lib/sources.js` — merges all sources into one catalog (currently just Pluto)
- `index.js` — optional local test server for running in Termux with `npm start` (not used by Netlify)
- `netlify.toml` — redirects that make the addon URLs look normal (`/manifest.json` etc.)

## IMPORTANT before you drag-and-drop

Netlify's drag-and-drop deploy does **not** run `npm install` for you.
The functions need `node-fetch` to work, so you have two options:

**Option A — run npm install first, then zip (works with pure drag & drop)**
In Termux, inside this folder:
```
npm install
```
Then re-zip the whole folder (this time including the new `node_modules/`) and drag that into Netlify.

**Option B — push to GitHub, connect the repo in Netlify instead (recommended)**
This matches how you already deploy everything else (KornDog Records site, KornDog Vault, etc.)
Netlify will run `npm install` automatically on every push, so you never have to remember to do it
manually or re-zip. Steps:
1. Push this folder to a new GitHub repo (e.g. `KornDog0804/korndog-sports-addon`)
2. Netlify → Add new site → Import an existing project → pick the repo
3. Build settings: leave build command blank, publish directory blank (nothing to build, it's just functions)
4. Deploy

Either way, once it's live your manifest URL will be:
```
https://YOUR-SITE-NAME.netlify.app/manifest.json
```
Paste that into Stremio → Settings → Addons → paste URL → Install.

## Testing the Pluto endpoint directly
If the catalog comes back empty, check what Pluto's boot endpoint is actually returning:
```
curl -s "https://boot.pluto.tv/v4/start?appName=web&appVersion=unknown&deviceVersion=unknown&deviceModel=web&deviceMake=chrome&deviceType=web&clientID=korndog-sports-addon&clientModelNumber=1.0" | head -c 2000
```
Paste the output back and the `lib/pluto.js` parsing can be adjusted to match the real shape.
